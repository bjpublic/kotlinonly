package learn.kotlin.com.pictureclient.mode.selected

class SelectedImageData {
    var mFile: String? = null
    var mData: String? = null
    var mType: Int = 0
    var mCheckedState: Boolean = false
}