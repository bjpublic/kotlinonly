package learn.kotlin.com.pictureclient.mode.auto

class AutoImageData {
    var mFile: String? = null
    var mData: String? = null
    var mDate: String? = null
}