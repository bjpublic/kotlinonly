package learn.kotlin.com.wordquiz

class Question (val questionData: String, val answerData: String)