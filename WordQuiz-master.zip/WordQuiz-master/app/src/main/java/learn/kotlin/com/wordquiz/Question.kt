package learn.kotlin.com.wordquiz

class Question (val english: String, val korean: String)